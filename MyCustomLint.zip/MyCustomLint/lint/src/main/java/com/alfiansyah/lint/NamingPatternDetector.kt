package com.alfiansyah.lint

@Suppress
class NamingPatternDetector {
}